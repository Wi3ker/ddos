import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, Home, CheckCircle } from "lucide-react";
import { collection, addDoc } from "firebase/firestore";
import { db } from "@/firebase";
import { useCartStore } from "@/stores/cartStore";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { WILAYAS } from "@/types";
import type { CheckoutFormData, DeliveryMethod } from "@/types";

export default function CheckoutPage() {
  const navigate = useNavigate();
  const { items, clearCart } = useCartStore();
  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0);
  const [orderId, setOrderId] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, boolean>>({});

  const [form, setForm] = useState<CheckoutFormData>({
    fullName: "", phone: "", instagram: "@", wilaya: "", commune: "", notes: "", deliveryMethod: "stop-desk",
  });

  useEffect(() => {
    if (items.length === 0 && !orderId) navigate("/");
  }, [items, orderId, navigate]);

  const update = (field: keyof CheckoutFormData, val: string) => {
    setForm(p => ({ ...p, [field]: val }));
    if (errors[field]) setErrors(e => ({ ...e, [field]: false }));
  };

  const deliveryFee = (() => {
    if (!form.wilaya || !WILAYAS[form.wilaya]) return 0;
    const p = WILAYAS[form.wilaya];
    return form.deliveryMethod === "stop-desk" ? p.stopDesk : p.home;
  })();

  const total = subtotal + deliveryFee;

  const validate = () => {
    const e: Record<string, boolean> = {};
    if (!form.fullName.trim()) e.fullName = true;
    if (!form.phone.trim()) e.phone = true;
    if (!form.wilaya) e.wilaya = true;
    if (!form.commune.trim()) e.commune = true;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handlePlaceOrder = async () => {
    if (!validate()) return;
    setSubmitting(true);
    try {
      const orderData = {
        formData: form,
        items: items.map(i => ({ product: i.product, quantity: i.quantity })),
        subtotal,
        deliveryFee,
        total,
        status: "in-progress",
        createdAt: Date.now(),
      };
      const ref = await addDoc(collection(db, "orders"), orderData);
      setOrderId(ref.id);
      clearCart();
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (orderId) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4" style={{ background: "#0C0C1A" }}>
        <motion.div initial={{ scale: 0.85, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
          className="flex flex-col items-center gap-6 text-center max-w-md">
          <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-500/10">
            <CheckCircle className="h-10 w-10 text-green-400" />
          </div>
          <h1 className="font-display text-3xl font-black tracking-widest text-white">COMMANDE CONFIRMÉE !</h1>
          <p className="text-sm text-[#8A8A9A]">
            Votre commande a été enregistrée. Nous vous contacterons bientôt pour confirmer. Paiement en espèces à la livraison.
          </p>
          <div className="border border-[#1E1E2E] px-6 py-3 text-center">
            <p className="text-xs text-[#8A8A9A] mb-1">N° de commande</p>
            <p className="font-display text-lg tracking-wider text-[#E40000]">{orderId.slice(0, 8).toUpperCase()}</p>
          </div>
          <Link to="/" className="btn-primary px-10 py-4 text-sm tracking-[0.3em]">RETOUR À LA BOUTIQUE</Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div style={{ background: "#0C0C1A", minHeight: "100vh" }}>
      <Navbar />
      <main style={{ paddingTop: "64px" }}>
        <div className="mx-auto max-w-[900px] px-4 py-12">
          <Link to="/" className="flex items-center gap-2 text-[#8A8A9A] hover:text-white mb-8 transition-colors">
            <ArrowLeft className="h-4 w-4" />
            <span className="font-display text-sm tracking-widest uppercase">Retour</span>
          </Link>

          <h1 className="font-display text-3xl font-black tracking-widest text-white mb-8">COMMANDE</h1>

          <div className="grid grid-cols-1 gap-8 lg:grid-cols-[1fr_340px]">
            {/* Form */}
            <div className="space-y-6">
              <div style={{ background: "#13131F", border: "1px solid #1E1E2E" }} className="p-6">
                <h2 className="font-display text-lg tracking-widest text-white mb-6 uppercase">Informations client</h2>
                <div className="space-y-4">
                  <div>
                    <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                      Nom complet <span className="text-[#E40000]">*</span>
                    </label>
                    <input type="text" value={form.fullName} onChange={e => update("fullName", e.target.value)}
                      placeholder="Votre nom complet" className={`field-input ${errors.fullName ? "error" : ""}`} />
                  </div>
                  <div>
                    <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                      Téléphone <span className="text-[#E40000]">*</span>
                    </label>
                    <input type="tel" value={form.phone} onChange={e => update("phone", e.target.value)}
                      placeholder="05XXXXXXXX" className={`field-input ${errors.phone ? "error" : ""}`} />
                  </div>
                  <div>
                    <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                      Instagram (optionnel)
                    </label>
                    <input type="text" value={form.instagram} onChange={e => update("instagram", e.target.value)}
                      placeholder="@votre_compte" className="field-input" />
                  </div>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                        Wilaya <span className="text-[#E40000]">*</span>
                      </label>
                      <select value={form.wilaya} onChange={e => update("wilaya", e.target.value)}
                        className={`field-input ${errors.wilaya ? "error" : ""}`}
                        style={{ background: "#0a0a16", color: form.wilaya ? "white" : "#8A8A9A" }}>
                        <option value="" style={{ color: "#8A8A9A" }}>Sélectionnez...</option>
                        {Object.keys(WILAYAS).map(w => (
                          <option key={w} value={w} style={{ color: "white", background: "#13131F" }}>{w}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                        Commune <span className="text-[#E40000]">*</span>
                      </label>
                      <input type="text" value={form.commune} onChange={e => update("commune", e.target.value)}
                        placeholder="Votre ville" className={`field-input ${errors.commune ? "error" : ""}`} />
                    </div>
                  </div>
                  <div>
                    <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">Notes (optionnel)</label>
                    <textarea value={form.notes} onChange={e => update("notes", e.target.value)}
                      placeholder="Informations supplémentaires..." rows={3}
                      className="field-input resize-none" />
                  </div>
                </div>
              </div>

              {/* Delivery Method */}
              <div style={{ background: "#13131F", border: "1px solid #1E1E2E" }} className="p-6">
                <h2 className="font-display text-lg tracking-widest text-white mb-6 uppercase">Mode de livraison</h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  {(["stop-desk", "home"] as DeliveryMethod[]).map(method => {
                    const active = form.deliveryMethod === method;
                    const fee = form.wilaya && WILAYAS[form.wilaya]
                      ? (method === "stop-desk" ? WILAYAS[form.wilaya].stopDesk : WILAYAS[form.wilaya].home)
                      : null;
                    return (
                      <button key={method} onClick={() => update("deliveryMethod", method)}
                        className="flex flex-col gap-2 p-4 text-left transition-all"
                        style={{ border: `1px solid ${active ? "#E40000" : "#1E1E2E"}`, background: active ? "#1a0a0a" : "#0C0C1A" }}>
                        <div className="flex items-center gap-2">
                          <span className="text-xl">{method === "stop-desk" ? "🏪" : "🏠"}</span>
                          <span className="font-display text-base tracking-widest text-white uppercase">
                            {method === "stop-desk" ? "Stop Desk" : "À domicile"}
                          </span>
                        </div>
                        <p className="text-xs text-[#8A8A9A]">
                          {method === "stop-desk" ? "Bureau de livraison" : "Livraison chez vous"}
                        </p>
                        {fee !== null && (
                          <p className="font-display text-sm font-bold text-[#E40000]">{fee.toLocaleString("fr-DZ")} DA</p>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Payment */}
              <div style={{ background: "#13131F", border: "1px solid #1E1E2E" }} className="p-6">
                <h2 className="font-display text-lg tracking-widest text-white mb-4 uppercase">Paiement</h2>
                <div className="flex items-center gap-3 p-4" style={{ border: "1px solid #1E1E2E", background: "#0C0C1A" }}>
                  <span className="text-2xl">💸</span>
                  <div>
                    <p className="font-display text-sm tracking-wider text-white uppercase">Paiement à la livraison</p>
                    <p className="text-xs text-[#8A8A9A]">Payez en espèces à la réception de votre commande</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Order Summary */}
            <div className="h-fit sticky top-24">
              <div style={{ background: "#13131F", border: "1px solid #1E1E2E" }} className="p-6">
                <h2 className="font-display text-lg tracking-widest text-white mb-6 uppercase">Récapitulatif</h2>
                <div className="space-y-3 mb-6">
                  {items.map(item => (
                    <div key={item.product.id} className="flex justify-between items-start gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-white truncate">{item.product.title}</p>
                        <p className="text-xs text-[#8A8A9A]">× {item.quantity}</p>
                      </div>
                      <span className="font-display text-sm text-[#E40000] flex-shrink-0">
                        {(item.product.price * item.quantity).toLocaleString("fr-DZ")} DA
                      </span>
                    </div>
                  ))}
                </div>

                <div className="space-y-2 pt-4" style={{ borderTop: "1px solid #1E1E2E" }}>
                  <div className="flex justify-between text-sm text-[#8A8A9A]">
                    <span>Sous-total</span><span>{subtotal.toLocaleString("fr-DZ")} DA</span>
                  </div>
                  <div className="flex justify-between text-sm text-[#8A8A9A]">
                    <span>Livraison</span>
                    <span>{deliveryFee > 0 ? `${deliveryFee.toLocaleString("fr-DZ")} DA` : "—"}</span>
                  </div>
                  <div className="flex justify-between items-center pt-3" style={{ borderTop: "1px solid #1E1E2E" }}>
                    <span className="font-display text-lg tracking-widest text-white uppercase">TOTAL</span>
                    <span className="font-display text-2xl font-black text-[#E40000]">{total.toLocaleString("fr-DZ")} DA</span>
                  </div>
                </div>

                <button onClick={handlePlaceOrder} disabled={submitting}
                  className="btn-primary w-full py-4 text-sm tracking-[0.3em] mt-6">
                  {submitting ? "EN COURS..." : "CONFIRMER LA COMMANDE"}
                </button>
                <p className="text-center text-[10px] text-[#8A8A9A] mt-3">💸 Paiement en espèces à la livraison</p>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
}
