import { useEffect, useState } from "react";
import { AnimatePresence } from "framer-motion";
import Navbar from "@/components/Navbar";
import HeroBanner from "@/components/HeroBanner";
import ProductGrid from "@/components/ProductGrid";
import CartDrawer from "@/components/CartDrawer";
import Footer from "@/components/Footer";
import SplashScreen from "@/components/SplashScreen";
import { initProductListener } from "@/stores/productStore";
import { seedDatabase } from "@/data/seed";

export default function StorePage() {
  const [showSplash, setShowSplash] = useState(() => !sessionStorage.getItem("dodds_visited"));

  useEffect(() => {
    const cleanup = initProductListener();
    seedDatabase();
    return cleanup;
  }, []);

  const handleSplashDone = () => {
    sessionStorage.setItem("dodds_visited", "true");
    setShowSplash(false);
  };

  return (
    <>
      <AnimatePresence>
        {showSplash && <SplashScreen onDone={handleSplashDone} />}
      </AnimatePresence>

      <Navbar />
      <main style={{ paddingTop: "64px" }}>
        <HeroBanner />

        {/* Info strip */}
        <section style={{ background: "#1A1A1A" }} className="py-8">
          <div className="mx-auto max-w-[1440px] px-5">
            <div className="grid grid-cols-3 gap-4 text-center">
              {[
                { icon: "📦", label: "Livraison vers 58 wilayas" },
                { icon: "💸", label: "Paiement à la livraison" },
                { icon: "📍", label: "Basé à Batna" },
              ].map(item => (
                <div key={item.label} className="flex flex-col items-center gap-1.5">
                  <span className="text-2xl">{item.icon}</span>
                  <p className="font-display text-[9px] tracking-[0.2em] text-white/40 uppercase leading-tight">{item.label}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <ProductGrid />
      </main>
      <Footer />
      <CartDrawer />
    </>
  );
}
