import { useEffect, useState } from "react";
import { collection, onSnapshot, query } from "firebase/firestore";
import { db } from "@/firebase";
import { LogOut, Plus, Edit2 } from "lucide-react";
import { useAuthStore } from "@/stores/authStore";
import AdminLogin from "@/components/admin/AdminLogin";
import OrderCard from "@/components/admin/OrderCard";
import ProductForm from "@/components/admin/ProductForm";
import { initProductListener } from "@/stores/productStore";
import { useProductStore } from "@/stores/productStore";
import type { Order, Product } from "@/types";

type Tab = "orders-active" | "orders-done" | "products";

export default function AdminPage() {
  const { isAuthenticated, logout } = useAuthStore();
  const [tab, setTab] = useState<Tab>("orders-active");
  const [orders, setOrders] = useState<Order[]>([]);
  const [editProduct, setEditProduct] = useState<Product | null | undefined>(undefined);
  const { products } = useProductStore();

  useEffect(() => {
    if (!isAuthenticated) return;
    const unsub1 = initProductListener();
    const q = query(collection(db, "orders"));
    const unsub2 = onSnapshot(q, snap => {
      setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() } as Order)));
    });
    return () => { unsub1(); unsub2(); };
  }, [isAuthenticated]);

  if (!isAuthenticated) return <AdminLogin />;

  const active = orders.filter(o => o.status === "in-progress");
  const done = orders.filter(o => o.status === "finished");

  const tabs: { key: Tab; label: string; count?: number }[] = [
    { key: "orders-active", label: "EN COURS", count: active.length },
    { key: "orders-done", label: "TERMINÉES", count: done.length },
    { key: "products", label: "PRODUITS", count: products.length },
  ];

  return (
    <div style={{ background: "#0C0C1A", minHeight: "100vh" }}>
      {/* Header */}
      <div className="sticky top-0 z-40" style={{ background: "#0C0C1A", borderBottom: "1px solid #1E1E2E" }}>
        <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between px-4 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center bg-[#E40000]">
              <span className="font-display text-lg font-black text-white leading-none">D</span>
            </div>
            <span className="font-display text-lg font-black tracking-[0.2em] text-white">DODDS ADMIN</span>
          </div>
          <button onClick={logout} className="flex items-center gap-2 text-[#8A8A9A] hover:text-white transition-colors">
            <LogOut className="h-4 w-4" />
            <span className="font-display text-xs tracking-widest uppercase">Déconnexion</span>
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div style={{ background: "#13131F", borderBottom: "1px solid #1E1E2E" }}>
        <div className="mx-auto max-w-[1440px] px-4 py-4 grid grid-cols-3 gap-4">
          <div className="text-center">
            <p className="font-display text-3xl font-black text-yellow-400">{active.length}</p>
            <p className="font-display text-[10px] tracking-widest text-[#8A8A9A] uppercase">En cours</p>
          </div>
          <div className="text-center">
            <p className="font-display text-3xl font-black text-green-400">{done.length}</p>
            <p className="font-display text-[10px] tracking-widest text-[#8A8A9A] uppercase">Terminées</p>
          </div>
          <div className="text-center">
            <p className="font-display text-3xl font-black text-[#E40000]">{products.length}</p>
            <p className="font-display text-[10px] tracking-widest text-[#8A8A9A] uppercase">Produits</p>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="sticky z-30" style={{ top: "64px", background: "#0C0C1A", borderBottom: "1px solid #1E1E2E" }}>
        <div className="mx-auto flex max-w-[1440px] px-4">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`px-6 py-4 font-display text-xs tracking-[0.2em] uppercase transition-all border-b-2 flex items-center gap-2 ${
                tab === t.key ? "border-[#E40000] text-[#E40000]" : "border-transparent text-[#8A8A9A] hover:text-white"
              }`}>
              {t.label}
              {t.count !== undefined && (
                <span className={`text-[10px] px-1.5 py-0.5 rounded-sm ${tab === t.key ? "bg-[#E40000] text-white" : "bg-[#1E1E2E] text-[#8A8A9A]"}`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="mx-auto max-w-[1440px] px-4 py-8">
        {tab === "orders-active" && (
          <div className="space-y-4">
            {active.length === 0
              ? <p className="text-center py-16 text-[#8A8A9A]">Aucune commande en cours</p>
              : active.map(o => <OrderCard key={o.id} order={o} />)
            }
          </div>
        )}
        {tab === "orders-done" && (
          <div className="space-y-4">
            {done.length === 0
              ? <p className="text-center py-16 text-[#8A8A9A]">Aucune commande terminée</p>
              : done.map(o => <OrderCard key={o.id} order={o} />)
            }
          </div>
        )}
        {tab === "products" && (
          <div>
            <div className="flex justify-end mb-6">
              <button onClick={() => setEditProduct(null)}
                className="btn-primary flex items-center gap-2 px-6 py-3 text-xs tracking-[0.2em]">
                <Plus className="h-4 w-4" /> AJOUTER PRODUIT
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
              {products.map(p => (
                <div key={p.id} className="product-card" onClick={() => setEditProduct(p)}>
                  <div style={{ aspectRatio: "2/3", background: "#0C0C1A" }} className="overflow-hidden relative">
                    <img src={p.coverImage} alt={p.title} className="h-full w-full object-cover" />
                    <div className="absolute inset-0 flex items-end p-2 opacity-0 hover:opacity-100 transition-opacity"
                      style={{ background: "linear-gradient(transparent, rgba(0,0,0,0.7))" }}>
                      <span className="flex items-center gap-1 text-white text-xs"><Edit2 className="h-3 w-3" /> Modifier</span>
                    </div>
                    {p.isNew && <div className="badge-new">NEW</div>}
                  </div>
                  <div className="p-2">
                    <p className="section-label text-[8px]">{p.series}</p>
                    <p className="font-display text-sm font-bold text-white leading-tight line-clamp-1">{p.title}</p>
                    <p className="font-display text-sm font-bold text-[#E40000]">{p.price.toLocaleString("fr-DZ")} DA</p>
                    <p className="text-[10px] text-[#8A8A9A]">{p.stock} en stock</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {editProduct !== undefined && (
        <ProductForm product={editProduct} onClose={() => setEditProduct(undefined)} />
      )}
    </div>
  );
}
