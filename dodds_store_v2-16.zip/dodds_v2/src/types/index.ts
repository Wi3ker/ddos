export type Category =
  | "All"
  | "Shōnen"
  | "Seinen"
  | "Shōjo"
  | "Slice of Life"
  | "Isekai"
  | "Special"
  | "Figurines"
  | "Accessories";

export interface Product {
  id: string;
  title: string;
  series: string;
  volume?: number;
  price: number;
  originalPrice?: number;
  stock: number;
  category: Category;
  coverImage: string;
  isNew: boolean;
  description?: string;
  createdAt?: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type DeliveryMethod = "stop-desk" | "home";

export interface CheckoutFormData {
  fullName: string;
  phone: string;
  instagram: string;
  wilaya: string;
  commune: string;
  notes: string;
  deliveryMethod: DeliveryMethod;
}

export interface Order {
  id: string;
  formData: CheckoutFormData;
  items: CartItem[];
  subtotal: number;
  deliveryFee: number;
  total: number;
  status: "in-progress" | "finished";
  createdAt: number;
}

export const WILAYAS: Record<string, { stopDesk: number; home: number }> = {
  "01 - Adrar": { stopDesk: 600, home: 800 },
  "02 - Chlef": { stopDesk: 400, home: 600 },
  "03 - Laghouat": { stopDesk: 500, home: 700 },
  "04 - Oum El Bouaghi": { stopDesk: 450, home: 650 },
  "05 - Batna": { stopDesk: 450, home: 650 },
  "06 - Béjaïa": { stopDesk: 400, home: 600 },
  "07 - Biskra": { stopDesk: 500, home: 700 },
  "08 - Béchar": { stopDesk: 600, home: 800 },
  "09 - Blida": { stopDesk: 350, home: 550 },
  "10 - Bouira": { stopDesk: 400, home: 600 },
  "11 - Tamanrasset": { stopDesk: 700, home: 900 },
  "12 - Tébessa": { stopDesk: 500, home: 700 },
  "13 - Tlemcen": { stopDesk: 450, home: 650 },
  "14 - Tiaret": { stopDesk: 450, home: 650 },
  "15 - Tizi Ouzou": { stopDesk: 400, home: 600 },
  "16 - Alger": { stopDesk: 300, home: 500 },
  "17 - Djelfa": { stopDesk: 500, home: 700 },
  "18 - Jijel": { stopDesk: 400, home: 600 },
  "19 - Sétif": { stopDesk: 400, home: 600 },
  "20 - Saïda": { stopDesk: 500, home: 700 },
  "21 - Skikda": { stopDesk: 450, home: 650 },
  "22 - Sidi Bel Abbès": { stopDesk: 450, home: 650 },
  "23 - Annaba": { stopDesk: 400, home: 600 },
  "24 - Guelma": { stopDesk: 450, home: 650 },
  "25 - Constantine": { stopDesk: 400, home: 600 },
  "26 - Médéa": { stopDesk: 400, home: 600 },
  "27 - Mostaganem": { stopDesk: 400, home: 600 },
  "28 - M'Sila": { stopDesk: 450, home: 650 },
  "29 - Mascara": { stopDesk: 450, home: 650 },
  "30 - Ouargla": { stopDesk: 550, home: 750 },
  "31 - Oran": { stopDesk: 400, home: 600 },
  "32 - El Bayadh": { stopDesk: 550, home: 750 },
  "33 - Illizi": { stopDesk: 700, home: 900 },
  "34 - Bordj Bou Arréridj": { stopDesk: 400, home: 600 },
  "35 - Boumerdès": { stopDesk: 350, home: 550 },
  "36 - El Tarf": { stopDesk: 450, home: 650 },
  "37 - Tindouf": { stopDesk: 700, home: 900 },
  "38 - Tissemsilt": { stopDesk: 450, home: 650 },
  "39 - El Oued": { stopDesk: 550, home: 750 },
  "40 - Khenchela": { stopDesk: 500, home: 700 },
  "41 - Souk Ahras": { stopDesk: 450, home: 650 },
  "42 - Tipaza": { stopDesk: 350, home: 550 },
  "43 - Mila": { stopDesk: 450, home: 650 },
  "44 - Aïn Defla": { stopDesk: 400, home: 600 },
  "45 - Naâma": { stopDesk: 550, home: 750 },
  "46 - Aïn Témouchent": { stopDesk: 450, home: 650 },
  "47 - Ghardaïa": { stopDesk: 550, home: 750 },
  "48 - Relizane": { stopDesk: 450, home: 650 },
  "49 - Timimoun": { stopDesk: 650, home: 850 },
  "50 - Bordj Badji Mokhtar": { stopDesk: 700, home: 900 },
  "51 - Ouled Djellal": { stopDesk: 550, home: 750 },
  "52 - Béni Abbès": { stopDesk: 650, home: 850 },
  "53 - In Salah": { stopDesk: 700, home: 900 },
  "54 - In Guezzam": { stopDesk: 750, home: 950 },
  "55 - Touggourt": { stopDesk: 550, home: 750 },
  "56 - Djanet": { stopDesk: 700, home: 900 },
  "57 - El M'Ghair": { stopDesk: 550, home: 750 },
  "58 - El Meniaa": { stopDesk: 600, home: 800 },
};
