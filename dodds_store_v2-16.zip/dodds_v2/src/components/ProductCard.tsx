import { motion } from "framer-motion";
import type { Product } from "@/types";

interface Props {
  product: Product;
  index: number;
  onClick: (product: Product) => void;
}

export default function ProductCard({ product, index, onClick }: Props) {
  const outOfStock = product.stock <= 0;
  const hasDiscount = product.originalPrice && product.originalPrice > product.price;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05, duration: 0.45 }}
      layout
      onClick={() => onClick(product)}
      className={`product-card group ${outOfStock ? "opacity-50" : ""}`}>

      {/* Image */}
      <div className="relative overflow-hidden bg-[#F0EEE9]" style={{ aspectRatio: "2/3" }}>
        <img src={product.coverImage} alt={product.title}
          className="h-full w-full object-cover" loading="lazy" />

        {outOfStock && (
          <div className="absolute inset-0 flex items-center justify-center bg-white/70">
            <span className="font-display text-[10px] tracking-[0.25em] text-[#111110] uppercase font-bold">Rupture</span>
          </div>
        )}

        {product.isNew && !outOfStock && <div className="badge-new">NOUVEAU</div>}

        {hasDiscount && (
          <div className="absolute right-0 top-3 bg-[#D42B2B] px-2 py-1">
            <span className="font-display text-[9px] font-bold tracking-widest text-white">SOLDE</span>
          </div>
        )}

        {/* Hover overlay */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
      </div>

      {/* Info */}
      <div className="p-3 bg-white">
        <p className="section-label text-[9px] mb-1">{product.series}</p>
        <h3 className="font-display text-[13px] font-bold leading-tight text-[#111110] tracking-wide line-clamp-2">
          {product.title}
        </h3>
        <div className="mt-2 flex items-baseline justify-between">
          <span className="font-display text-sm font-black text-[#111110]">
            {product.price.toLocaleString("fr-DZ")} <span className="text-[10px] font-bold">DA</span>
          </span>
          {hasDiscount && (
            <span className="text-[10px] text-[#BEBEBB] line-through">
              {product.originalPrice?.toLocaleString("fr-DZ")} DA
            </span>
          )}
        </div>
        <p className="mt-0.5 text-[10px] text-[#BEBEBB]">
          {outOfStock ? "Indisponible" : `${product.stock} en stock`}
        </p>
      </div>
    </motion.div>
  );
}
