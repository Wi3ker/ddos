import { motion } from "framer-motion";
import { LOGO_B64 } from "@/logoB64";

interface Props { onDone: () => void; }

export default function SplashScreen({ onDone }: Props) {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6 }}
      onAnimationComplete={() => setTimeout(onDone, 2200)}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#111110]"
    >
      <motion.div
        initial={{ scale: 0.85, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
        className="flex flex-col items-center gap-5"
      >
        <motion.img
          src={LOGO_B64}
          alt="Dodds Store"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="w-20 h-20 object-cover rounded-full"
          style={{ border: "2px solid rgba(255,255,255,0.15)" }}
        />

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25, duration: 0.5 }}
          className="text-center"
        >
          <h1 className="font-display text-4xl font-black tracking-[0.2em] text-white">DODDS STORE</h1>
          <p className="mt-2 font-display text-[10px] tracking-[0.4em] text-white/30 uppercase">
            Manga · Figurines · Accessoires
          </p>
        </motion.div>
      </motion.div>

      {/* Loading bar */}
      <motion.div
        initial={{ width: 0 }}
        animate={{ width: "120px" }}
        transition={{ delay: 0.5, duration: 1.5, ease: "easeInOut" }}
        className="absolute bottom-16 h-[1px] bg-white/30"
      />
    </motion.div>
  );
}
