import { useState, useEffect } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "@/firebase";
import { motion } from "framer-motion";
import ProductCard from "@/components/ProductCard";
import ProductModal from "@/components/ProductModal";
import type { Product, Category } from "@/types";

const CATEGORIES: Category[] = [
  "All", "Shōnen", "Seinen", "Shōjo", "Slice of Life", "Isekai", "Special", "Figurines", "Accessories",
];

const CAT_LABELS: Record<string, string> = {
  All: "Tout voir", "Shōnen": "Shōnen", "Seinen": "Seinen", "Shōjo": "Shōjo",
  "Slice of Life": "Slice of Life", "Isekai": "Isekai", "Special": "Spécial",
  "Figurines": "Figurines", "Accessories": "Accessoires",
};

export default function ProductGrid() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<Category>("All");
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Direct Firebase listener — no Zustand, no orderBy
  useEffect(() => {
    const unsub = onSnapshot(
      collection(db, "products"),
      (snap) => {
        const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Product));
        data.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setProducts(data);
        setIsLoading(false);
      },
      (err) => {
        console.error("ProductGrid Firebase error:", err);
        setIsLoading(false);
      }
    );
    return () => unsub();
  }, []);

  const filtered = selectedCategory === "All"
    ? products
    : products.filter(p => p.category === selectedCategory);

  return (
    <>
      <section id="products-section" className="bg-[#F5F4F0]">
        {/* Header */}
        <div className="px-5 lg:px-10 pt-14 pb-6 max-w-[1440px] mx-auto">
          <p className="section-label mb-2">Notre sélection</p>
          <div className="flex items-end justify-between">
            <h2 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: "clamp(32px,8vw,56px)",
              color: "#111110", letterSpacing: "-0.01em", lineHeight: 1 }}>
              COLLECTION
            </h2>
            <span style={{ fontFamily: "Syne,sans-serif", fontSize: 12, color: "#BEBEBB", fontWeight: 700 }}
              className="hidden sm:block">
              {products.length} produits
            </span>
          </div>
          <div className="mt-5 h-px bg-[#E0DED8]" />
        </div>

        {/* Filter bar */}
        <div className="sticky top-16 z-30 bg-[#F5F4F0] border-b border-[#E0DED8] overflow-x-auto"
          style={{ scrollbarWidth: "none" }}>
          <div className="flex px-5 min-w-max">
            {CATEGORIES.map(cat => (
              <button key={cat} onClick={() => setSelectedCategory(cat)}
                style={{
                  fontFamily: "Syne,sans-serif", fontSize: 10, fontWeight: 700,
                  letterSpacing: "0.2em", textTransform: "uppercase",
                  padding: "14px 16px", border: "none", background: "none",
                  cursor: "pointer", whiteSpace: "nowrap",
                  color: selectedCategory === cat ? "#111110" : "#BEBEBB",
                  borderBottom: selectedCategory === cat ? "2px solid #111110" : "2px solid transparent",
                  transition: "all .2s",
                }}>
                {CAT_LABELS[cat]}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <div className="mx-auto max-w-[1440px] px-4 py-6">
          {isLoading ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="animate-pulse bg-white">
                  <div className="bg-[#F0EEE9]" style={{ aspectRatio: "2/3" }} />
                  <div className="p-3 space-y-2">
                    <div className="h-2 w-1/3 bg-[#F0EEE9] rounded" />
                    <div className="h-3 bg-[#F0EEE9] rounded" />
                    <div className="h-3 w-2/3 bg-[#F0EEE9] rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="py-28 text-center">
              <p style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 28,
                color: "#E0DED8", letterSpacing: "0.15em" }}>
                AUCUN PRODUIT
              </p>
            </div>
          ) : (
            <motion.div layout
              className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {filtered.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} onClick={setSelectedProduct} />
              ))}
            </motion.div>
          )}
        </div>
      </section>

      <ProductModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
    </>
  );
}
