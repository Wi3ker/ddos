import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Minus, Plus } from "lucide-react";
import type { Product } from "@/types";
import { useCartStore } from "@/stores/cartStore";

interface Props {
  product: Product | null;
  onClose: () => void;
}

export default function ProductModal({ product, onClose }: Props) {
  const [qty, setQty] = useState(1);
  const { addItem, openDrawer } = useCartStore();

  const handleAdd = () => {
    if (!product) return;
    addItem(product, qty);
    onClose();
    openDrawer();
  };

  return (
    <AnimatePresence onExitComplete={() => setQty(1)}>
      {product && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={onClose} className="fixed inset-0 z-50" style={{ background: "rgba(0,0,0,0.75)" }} />

          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="fixed bottom-0 left-0 right-0 z-50 bg-[#13131F] md:inset-0 md:m-auto md:h-fit md:max-w-lg"
            style={{ maxHeight: "92dvh", overflowY: "auto", borderTop: "2px solid #E40000" }}>

            <div className="flex flex-col md:flex-row">
              {/* Cover */}
              <div className="w-full md:w-52 flex-shrink-0 bg-[#0C0C1A]" style={{ aspectRatio: "2/3" }}>
                <img src={product.coverImage} alt={product.title} className="h-full w-full object-cover" />
              </div>

              {/* Details */}
              <div className="flex flex-1 flex-col p-6">
                <button onClick={onClose} className="ml-auto text-[#8A8A9A] hover:text-white mb-4 transition-colors">
                  <X className="h-5 w-5" />
                </button>

                <p className="section-label text-[9px]">{product.series}</p>
                <h2 className="mt-1 font-display text-2xl font-black leading-tight text-white uppercase tracking-wide">
                  {product.title}
                </h2>

                {product.description && (
                  <p className="mt-3 text-sm leading-relaxed text-[#8A8A9A] line-clamp-3">{product.description}</p>
                )}

                <div className="mt-4 flex items-baseline gap-3">
                  <span className="font-display text-3xl font-black text-[#E40000]">
                    {product.price.toLocaleString("fr-DZ")} DA
                  </span>
                  {product.originalPrice && product.originalPrice > product.price && (
                    <span className="text-sm text-[#8A8A9A] line-through">
                      {product.originalPrice.toLocaleString("fr-DZ")} DA
                    </span>
                  )}
                </div>

                <p className="mt-1 text-xs text-[#8A8A9A]">
                  {product.stock > 0 ? `✓ ${product.stock} en stock` : `✗ Rupture de stock`}
                </p>

                {/* Qty selector */}
                {product.stock > 0 && (
                  <div className="mt-5 flex items-center gap-4">
                    <span className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase">Qté</span>
                    <div className="flex items-center" style={{ border: "1px solid #1E1E2E" }}>
                      <button onClick={() => setQty(q => Math.max(1, q - 1))}
                        className="flex h-9 w-9 items-center justify-center text-[#8A8A9A] hover:text-[#E40000] transition-colors">
                        <Minus className="h-3 w-3" />
                      </button>
                      <span className="w-10 text-center font-display text-base font-bold text-white">{qty}</span>
                      <button onClick={() => setQty(q => Math.min(product.stock, q + 1))}
                        className="flex h-9 w-9 items-center justify-center text-[#8A8A9A] hover:text-[#E40000] transition-colors">
                        <Plus className="h-3 w-3" />
                      </button>
                    </div>
                  </div>
                )}

                <button onClick={handleAdd} disabled={product.stock <= 0}
                  className="btn-primary mt-5 py-4 text-sm tracking-[0.3em] w-full">
                  {product.stock > 0 ? "AJOUTER AU PANIER" : "RUPTURE DE STOCK"}
                </button>
                <button onClick={onClose}
                  className="mt-3 py-2 font-display text-xs tracking-widest text-[#8A8A9A] uppercase hover:text-white transition-colors">
                  FERMER
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
