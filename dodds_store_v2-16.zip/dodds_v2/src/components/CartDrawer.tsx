import { motion, AnimatePresence } from "framer-motion";
import { X, ShoppingCart } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useCartStore } from "@/stores/cartStore";

export default function CartDrawer() {
  const { items, isOpen, closeDrawer, removeItem } = useCartStore();
  const navigate = useNavigate();
  const totalItems = items.reduce((s, i) => s + i.quantity, 0);
  const subtotal = items.reduce((s, i) => s + i.product.price * i.quantity, 0);

  const handleCheckout = () => {
    closeDrawer();
    navigate("/checkout");
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={closeDrawer} className="fixed inset-0 z-50" style={{ background: "rgba(0,0,0,0.6)" }} />

          <motion.div initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="fixed right-0 top-0 z-50 flex h-full w-full max-w-sm flex-col"
            style={{ background: "#13131F", borderLeft: "1px solid #1E1E2E" }}>

            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5" style={{ borderBottom: "1px solid #1E1E2E" }}>
              <div className="flex items-center gap-3">
                <ShoppingCart className="h-5 w-5 text-[#E40000]" />
                <span className="font-display text-xl tracking-widest text-white">PANIER ({totalItems})</span>
              </div>
              <button onClick={closeDrawer} className="text-[#8A8A9A] hover:text-white transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Items */}
            <div className="flex-1 overflow-y-auto px-6 py-4">
              {items.length === 0 ? (
                <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
                  <ShoppingCart className="h-12 w-12 text-[#1E1E2E]" />
                  <p className="text-sm text-[#8A8A9A]">Votre panier est vide</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {items.map(item => (
                    <div key={item.product.id} className="flex gap-4 pb-4" style={{ borderBottom: "1px solid #1E1E2E" }}>
                      <img src={item.product.coverImage} alt={item.product.title}
                        className="h-20 w-14 flex-shrink-0 object-cover" style={{ background: "#0C0C1A" }} />
                      <div className="flex flex-1 flex-col justify-between">
                        <div>
                          <p className="section-label text-[9px]">{item.product.series}</p>
                          <p className="font-display text-sm font-bold leading-tight text-white">{item.product.title}</p>
                          <p className="mt-1 text-xs text-[#8A8A9A]">Qté: {item.quantity}</p>
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="font-display text-sm font-bold text-[#E40000]">
                            {(item.product.price * item.quantity).toLocaleString("fr-DZ")} DA
                          </span>
                          <button onClick={() => removeItem(item.product.id)}
                            className="font-display text-[10px] uppercase tracking-widest text-[#8A8A9A] hover:text-[#E40000] transition-colors">
                            Supprimer
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Footer */}
            {items.length > 0 && (
              <div className="px-6 py-5" style={{ borderTop: "1px solid #1E1E2E" }}>
                <div className="mb-4 flex items-center justify-between">
                  <span className="text-sm text-[#8A8A9A] uppercase tracking-wider">Sous-total</span>
                  <span className="font-display text-xl font-bold text-white">{subtotal.toLocaleString("fr-DZ")} DA</span>
                </div>
                <button onClick={handleCheckout} className="btn-primary w-full py-4 text-sm tracking-[0.3em]">
                  COMMANDER
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
