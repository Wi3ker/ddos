import { motion } from "framer-motion";
import { ArrowDown } from "lucide-react";
import { LOGO_B64 } from "@/logoB64";
import seedData from "@/seedProducts.json";

const HERO_BOOKS = (seedData as any[]).slice(0, 6);

export default function HeroBanner() {
  const scrollToProducts = () => {
    document.getElementById("products-section")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      style={{
        position: "relative",
        width: "100%",
        minHeight: "100svh",
        background: "#111110",
        overflowX: "clip",  /* clip not hidden */
        overflowY: "visible",
      }}
    >
      {/* MOBILE: 4 books in a strip at top */}
      <div className="block md:hidden" style={{ position: "relative", width: "100%", height: "46vw", overflow: "hidden" }}>
        {HERO_BOOKS.slice(0, 4).map((p: any, i: number) => {
          const offsets = [
            { left: "2%",  top: "-8%", rotate: -6 },
            { left: "25%", top:  "3%", rotate:  3 },
            { left: "48%", top: "-5%", rotate: -5 },
            { left: "70%", top:  "4%", rotate:  4 },
          ];
          const o = offsets[i];
          return (
            <motion.div key={i}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.1, duration: 0.55 }}
              style={{
                position: "absolute",
                left: o.left,
                top: o.top,
                width: "27vw",
                transform: `rotate(${o.rotate}deg)`,
                boxShadow: "0 10px 28px rgba(0,0,0,0.7)",
                zIndex: 4 - i,
              }}
            >
              <img src={p.b64} alt={p.title}
                style={{ width: "100%", aspectRatio: "2/3", display: "block", objectFit: "cover" }} />
            </motion.div>
          );
        })}
        {/* fade bottom of strip */}
        <div style={{
          position: "absolute", bottom: 0, left: 0, right: 0, height: "48px", pointerEvents: "none",
          background: "linear-gradient(to top, #111110, transparent)",
        }} />
      </div>

      {/* DESKTOP: books absolutely positioned on right */}
      <div className="hidden md:block" style={{ position: "absolute", inset: 0, pointerEvents: "none", overflow: "hidden" }}>
        {HERO_BOOKS.map((p: any, i: number) => {
          const pos = [
            { top: "6%",  right: "3%",  w: 158, r:  4 },
            { top: "20%", right: "21%", w: 136, r: -3 },
            { top: "40%", right: "5%",  w: 146, r:  6 },
            { top: "8%",  right: "37%", w: 120, r: -5 },
            { top: "54%", right: "22%", w: 128, r:  2 },
            { top: "62%", right: "4%",  w: 112, r: -4 },
          ][i];
          return (
            <motion.div key={i}
              initial={{ opacity: 0, y: 40 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 + i * 0.12, duration: 0.8 }}
              style={{
                position: "absolute",
                top: pos.top, right: pos.right,
                width: `${pos.w}px`,
                transform: `rotate(${pos.r}deg)`,
                boxShadow: "0 20px 60px rgba(0,0,0,0.6)",
                zIndex: 6 - i,
              }}
            >
              <img src={p.b64} alt={p.title}
                style={{ width: "100%", aspectRatio: "2/3", display: "block", objectFit: "cover" }} />
            </motion.div>
          );
        })}
        {/* left gradient protecting text */}
        <div style={{
          position: "absolute", inset: 0, pointerEvents: "none",
          background: "linear-gradient(to right, #111110 38%, rgba(17,17,16,0.65) 58%, transparent 78%)",
        }} />
        <div style={{
          position: "absolute", bottom: 0, left: 0, right: 0, height: "120px", pointerEvents: "none",
          background: "linear-gradient(to top, #111110, transparent)",
        }} />
      </div>

      {/* TEXT CONTENT — always full width */}
      <div style={{
        position: "relative",
        zIndex: 10,
        width: "100%",
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: "16px 24px 64px",
        maxWidth: "520px",
      }}>
        <motion.img src={LOGO_B64} alt="Logo"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          style={{ width: 44, height: 44, borderRadius: "50%", objectFit: "cover",
            border: "2px solid rgba(255,255,255,0.15)", marginBottom: 20 }} />

        <motion.div initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
          <div style={{ width: 18, height: 1, background: "#D42B2B" }} />
          <span style={{ fontFamily: "Syne,sans-serif", fontSize: 9, letterSpacing: "0.3em",
            color: "#D42B2B", textTransform: "uppercase", fontWeight: 700 }}>
            Manga · Figurines · Accessoires
          </span>
        </motion.div>

        <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3, duration: 0.65 }}
          style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, color: "white",
            lineHeight: 0.88, letterSpacing: "-0.01em", fontSize: "clamp(52px,15vw,108px)",
            marginBottom: 18 }}>
          DODDS<br /><span style={{ color: "#D42B2B" }}>STORE</span>
        </motion.h1>

        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
          style={{ color: "rgba(255,255,255,0.4)", fontSize: 12, letterSpacing: "0.08em", marginBottom: 6 }}>
          📍 Batna — 🇩🇿 Livraison 58 Wilayas
        </motion.p>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.6 }}
          style={{ color: "rgba(255,255,255,0.2)", fontSize: 11, letterSpacing: "0.15em", marginBottom: 28 }}>
          Pièces uniques & introuvables
        </motion.p>

        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.75 }}
          style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <button onClick={scrollToProducts}
            style={{ background: "white", color: "#111110", fontFamily: "Syne,sans-serif",
              fontWeight: 700, fontSize: 11, letterSpacing: "0.15em", textTransform: "uppercase",
              padding: "13px 24px", border: "none", cursor: "pointer" }}>
            VOIR LA COLLECTION
          </button>
          <button onClick={scrollToProducts}
            style={{ color: "rgba(255,255,255,0.3)", fontFamily: "Syne,sans-serif", fontSize: 10,
              letterSpacing: "0.2em", textTransform: "uppercase", background: "none", border: "none", cursor: "pointer" }}>
            {(seedData as any[]).length} PRODUITS →
          </button>
        </motion.div>
      </div>

      {/* Scroll hint */}
      <motion.button initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.6 }}
        onClick={scrollToProducts}
        style={{ position: "absolute", bottom: 20, left: 24, zIndex: 10,
          display: "flex", alignItems: "center", gap: 6,
          color: "rgba(255,255,255,0.2)", background: "none", border: "none", cursor: "pointer" }}>
        <motion.div animate={{ y: [0, 5, 0] }} transition={{ duration: 2, repeat: Infinity }}>
          <ArrowDown style={{ width: 14, height: 14 }} />
        </motion.div>
        <span style={{ fontFamily: "Syne,sans-serif", fontSize: 9, letterSpacing: "0.3em", textTransform: "uppercase" }}>
          Défiler
        </span>
      </motion.button>
    </section>
  );
}
