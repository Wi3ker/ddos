import { useState } from "react";
import { useAuthStore } from "@/stores/authStore";

export default function AdminLogin() {
  const [pw, setPw] = useState("");
  const [error, setError] = useState(false);
  const { login } = useAuthStore();

  const handleLogin = () => {
    const correct = import.meta.env.VITE_ADMIN_PASSWORD || "dodds2025";
    if (pw === correct) {
      login(pw);
    } else {
      setError(true);
      setTimeout(() => setError(false), 2500);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4" style={{ background: "#0C0C1A" }}>
      <div className="w-full max-w-sm">
        <div className="relative p-8" style={{ background: "#13131F", border: "1px solid #1E1E2E" }}>
          <div className="absolute top-0 left-0 right-0 h-[2px] bg-[#E40000]" />

          <div className="text-center mb-8">
            <div className="flex h-12 w-12 items-center justify-center bg-[#E40000] mx-auto mb-4">
              <span className="font-display text-2xl font-black text-white">D</span>
            </div>
            <h1 className="font-display text-2xl font-black tracking-[0.2em] text-white">DODDS ADMIN</h1>
            <p className="text-xs text-[#8A8A9A] mt-1">Accès réservé au propriétaire</p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="font-display text-xs tracking-widest text-[#8A8A9A] uppercase mb-1.5 block">
                Mot de passe
              </label>
              <input
                type="password"
                value={pw}
                onChange={e => setPw(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleLogin()}
                placeholder="••••••••"
                className={`field-input ${error ? "error" : ""}`}
              />
            </div>
            {error && (
              <p className="text-xs text-[#E40000] text-center">Mot de passe incorrect</p>
            )}
            <button onClick={handleLogin} className="btn-primary w-full py-3 text-sm tracking-[0.3em]">
              CONNEXION
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
