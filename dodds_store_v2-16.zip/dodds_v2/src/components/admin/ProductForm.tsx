import { useState, useRef } from "react";
import { collection, addDoc, updateDoc, deleteDoc, doc } from "firebase/firestore";
import { db } from "@/firebase";
import { X, Upload, Loader2 } from "lucide-react";
import type { Product, Category } from "@/types";
import { CATEGORIES } from "@/stores/productStore";

const IMGBB_API_KEY = "467e83ddd1936a624352b5f0bd5e87fc";

interface Props {
  product?: Product | null;
  onClose: () => void;
}

const EMPTY: Omit<Product, "id"> = {
  title: "", series: "", volume: 1, price: 1500, stock: 10,
  category: "Shōnen", coverImage: "", isNew: false, description: "", createdAt: Date.now(),
};

async function uploadToImgBB(file: File): Promise<string> {
  const formData = new FormData();
  formData.append("image", file);
  const res = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
    method: "POST",
    body: formData,
  });
  if (!res.ok) throw new Error("Upload failed");
  const data = await res.json();
  return data.data.url as string;
}

export default function ProductForm({ product, onClose }: Props) {
  const [form, setForm] = useState(product ? { ...product } : { ...EMPTY });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [uploadError, setUploadError] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const isEdit = !!product;

  const update = (field: string, val: unknown) => setForm(p => ({ ...p, [field]: val }));

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadError("");
    try {
      const url = await uploadToImgBB(file);
      update("coverImage", url);
    } catch {
      setUploadError("Échec de l'upload. Réessayez.");
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (!form.title || !form.series || !form.price) return;
    setSaving(true);
    try {
      if (isEdit && product) {
        const { id, ...data } = form as Product;
        await updateDoc(doc(db, "products", id), data);
      } else {
        await addDoc(collection(db, "products"), { ...form, createdAt: Date.now() });
      }
      onClose();
    } catch (err) { console.error(err); }
    finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!product || !confirm("Supprimer ce produit ?")) return;
    setDeleting(true);
    try {
      await deleteDoc(doc(db, "products", product.id));
      onClose();
    } catch (err) { console.error(err); }
    finally { setDeleting(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center px-4" onClick={onClose}>
      <div className="absolute inset-0" style={{ background: "rgba(0,0,0,0.85)" }} />
      <div className="relative w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-2xl sm:rounded-none"
        style={{ background: "#111110", border: "1px solid #222", borderTop: "2px solid #D42B2B" }}
        onClick={e => e.stopPropagation()}>

        {/* Header */}
        <div className="flex items-center justify-between p-5" style={{ borderBottom: "1px solid #222" }}>
          <h2 style={{ fontFamily: "Syne,sans-serif", fontWeight: 800, fontSize: 16,
            letterSpacing: "0.15em", color: "white", textTransform: "uppercase" }}>
            {isEdit ? "Modifier" : "Nouveau produit"}
          </h2>
          <button onClick={onClose} style={{ color: "#666" }}>
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Title */}
          <div>
            <label className="field-label block mb-1.5">Titre</label>
            <input type="text" value={form.title} onChange={e => update("title", e.target.value)}
              placeholder="Titre du produit" className="field-input" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="field-label block mb-1.5">Série</label>
              <input type="text" value={form.series} onChange={e => update("series", e.target.value)}
                placeholder="Nom de la série" className="field-input" />
            </div>
            <div>
              <label className="field-label block mb-1.5">Volume</label>
              <input type="number" value={form.volume || ""} onChange={e => update("volume", Number(e.target.value))}
                placeholder="1" className="field-input" />
            </div>
            <div>
              <label className="field-label block mb-1.5">Prix (DA)</label>
              <input type="number" value={form.price} onChange={e => update("price", Number(e.target.value))}
                className="field-input" />
            </div>
            <div>
              <label className="field-label block mb-1.5">Stock</label>
              <input type="number" value={form.stock} onChange={e => update("stock", Number(e.target.value))}
                className="field-input" />
            </div>
          </div>

          <div>
            <label className="field-label block mb-1.5">Catégorie</label>
            <select value={form.category} onChange={e => update("category", e.target.value as Category)}
              className="field-input" style={{ background: "#F5F4F0", color: "#111110" }}>
              {CATEGORIES.filter(c => c !== "All").map(c => (
                <option key={c} value={c} style={{ background: "#F5F4F0", color: "#111110" }}>{c}</option>
              ))}
            </select>
          </div>

          {/* Image Upload — ImgBB */}
          <div>
            <label className="field-label block mb-1.5">Image de couverture</label>
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange}
              style={{ display: "none" }} />

            <div className="flex gap-2">
              <input type="text" value={form.coverImage} onChange={e => update("coverImage", e.target.value)}
                placeholder="URL ou uploader une image" className="field-input flex-1"
                style={{ fontSize: 12 }} />
              <button type="button" onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                style={{
                  display: "flex", alignItems: "center", gap: 6, padding: "0 14px",
                  border: "1.5px solid #333", color: uploading ? "#666" : "white",
                  background: "transparent", cursor: uploading ? "not-allowed" : "pointer",
                  fontFamily: "Syne,sans-serif", fontSize: 11, fontWeight: 700,
                  letterSpacing: "0.1em", textTransform: "uppercase", flexShrink: 0,
                  whiteSpace: "nowrap",
                }}>
                {uploading
                  ? <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Upload...</>
                  : <><Upload className="h-3.5 w-3.5" /> Photo</>
                }
              </button>
            </div>

            {uploadError && (
              <p style={{ color: "#D42B2B", fontSize: 11, marginTop: 6 }}>{uploadError}</p>
            )}

            {form.coverImage && !form.coverImage.startsWith("data:") && (
              <img src={form.coverImage} alt="preview"
                className="mt-2 h-24 w-16 object-cover"
                style={{ border: "1px solid #333" }} />
            )}
            {form.coverImage && form.coverImage.startsWith("data:") && (
              <p style={{ fontSize: 11, color: "#666", marginTop: 6 }}>
                ✓ Image intégrée (seed)
              </p>
            )}
          </div>

          <div>
            <label className="field-label block mb-1.5">Description (optionnel)</label>
            <textarea value={form.description || ""} onChange={e => update("description", e.target.value)}
              rows={2} placeholder="Description courte..." className="field-input resize-none" />
          </div>

          {/* New toggle */}
          <label className="flex items-center gap-3 cursor-pointer">
            <div style={{ position: "relative", width: 40, height: 20 }}>
              <input type="checkbox" checked={form.isNew} onChange={e => update("isNew", e.target.checked)}
                style={{ display: "none" }} />
              <div style={{
                width: "100%", height: "100%", borderRadius: 999,
                background: form.isNew ? "#D42B2B" : "#333", transition: "background .2s",
              }}>
                <div style={{
                  position: "absolute", top: 2, left: 2, width: 16, height: 16,
                  borderRadius: "50%", background: "white", transition: "transform .2s",
                  transform: form.isNew ? "translateX(20px)" : "translateX(0)",
                }} />
              </div>
            </div>
            <span style={{ fontFamily: "Syne,sans-serif", fontSize: 12, fontWeight: 700,
              letterSpacing: "0.15em", color: "#888", textTransform: "uppercase" }}>
              Nouveau
            </span>
          </label>
        </div>

        {/* Footer */}
        <div className="flex gap-3 p-5" style={{ borderTop: "1px solid #222" }}>
          {isEdit && (
            <button onClick={handleDelete} disabled={deleting}
              style={{ padding: "12px 16px", border: "1.5px solid #D42B2B", color: "#D42B2B",
                background: "transparent", fontFamily: "Syne,sans-serif", fontSize: 11,
                fontWeight: 700, letterSpacing: "0.15em", textTransform: "uppercase", cursor: "pointer" }}>
              {deleting ? "..." : "SUPPRIMER"}
            </button>
          )}
          <button onClick={handleSave} disabled={saving}
            style={{
              flex: 1, padding: "12px", background: "white", color: "#111110",
              fontFamily: "Syne,sans-serif", fontSize: 12, fontWeight: 700,
              letterSpacing: "0.15em", textTransform: "uppercase",
              border: "none", cursor: saving ? "not-allowed" : "pointer", opacity: saving ? 0.7 : 1,
            }}>
            {saving ? "ENREGISTREMENT..." : "ENREGISTRER"}
          </button>
        </div>
      </div>
    </div>
  );
}
