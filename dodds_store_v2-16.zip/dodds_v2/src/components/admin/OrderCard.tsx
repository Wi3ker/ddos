import { doc, updateDoc } from "firebase/firestore";
import { db } from "@/firebase";
import type { Order } from "@/types";

interface Props {
  order: Order;
}

export default function OrderCard({ order }: Props) {
  const date = new Date(order.createdAt).toLocaleDateString("fr-DZ", {
    day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit",
  });

  const markDone = async () => {
    await updateDoc(doc(db, "orders", order.id), { status: "finished" });
  };

  const markInProgress = async () => {
    await updateDoc(doc(db, "orders", order.id), { status: "in-progress" });
  };

  return (
    <div style={{ background: "#13131F", border: "1px solid #1E1E2E" }} className="p-5 space-y-4">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="font-display text-lg font-bold text-white">{order.formData.fullName}</p>
          <p className="text-sm text-[#8A8A9A]">{order.formData.phone}</p>
          {order.formData.instagram && order.formData.instagram !== "@" && (
            <p className="text-xs text-[#8A8A9A]">{order.formData.instagram}</p>
          )}
        </div>
        <div className="text-right flex-shrink-0">
          <p className="font-display text-xs tracking-widest text-[#8A8A9A]">{date}</p>
          <p className="font-display text-[10px] text-white/30 mt-1">#{order.id.slice(0, 8).toUpperCase()}</p>
        </div>
      </div>

      {/* Location */}
      <div className="flex items-center gap-3 text-sm text-[#8A8A9A]">
        <span>📍 {order.formData.wilaya} — {order.formData.commune}</span>
        <span className="text-[#E40000]">
          {order.formData.deliveryMethod === "stop-desk" ? "🏪 Stop Desk" : "🏠 Domicile"}
        </span>
      </div>

      {/* Items */}
      <div className="space-y-1" style={{ borderTop: "1px solid #1E1E2E", paddingTop: "12px" }}>
        {order.items.map((item, i) => (
          <div key={i} className="flex justify-between text-sm">
            <span className="text-[#8A8A9A]">{item.product.title} × {item.quantity}</span>
            <span className="text-white">{(item.product.price * item.quantity).toLocaleString("fr-DZ")} DA</span>
          </div>
        ))}
      </div>

      {/* Total */}
      <div className="flex justify-between items-center" style={{ borderTop: "1px solid #1E1E2E", paddingTop: "12px" }}>
        <div className="text-sm text-[#8A8A9A]">
          <span>Livraison: {order.deliveryFee.toLocaleString("fr-DZ")} DA</span>
        </div>
        <div className="text-right">
          <span className="font-display text-xl font-black text-[#E40000]">{order.total.toLocaleString("fr-DZ")} DA</span>
        </div>
      </div>

      {order.formData.notes && (
        <p className="text-xs text-[#8A8A9A] italic">📝 {order.formData.notes}</p>
      )}

      {/* Actions */}
      <div className="flex gap-3" style={{ borderTop: "1px solid #1E1E2E", paddingTop: "12px" }}>
        {order.status === "in-progress" ? (
          <button onClick={markDone} className="btn-primary flex-1 py-2.5 text-xs tracking-[0.2em]">
            ✓ MARQUER TERMINÉ
          </button>
        ) : (
          <button onClick={markInProgress}
            className="flex-1 py-2.5 text-xs tracking-[0.2em] font-display uppercase transition-colors"
            style={{ border: "1px solid #1E1E2E", color: "#8A8A9A" }}
            onMouseEnter={e => (e.currentTarget.style.borderColor = "#E40000")}
            onMouseLeave={e => (e.currentTarget.style.borderColor = "#1E1E2E")}>
            ↩ REMETTRE EN COURS
          </button>
        )}
      </div>
    </div>
  );
}
