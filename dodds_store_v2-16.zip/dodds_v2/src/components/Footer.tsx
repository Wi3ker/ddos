import { Instagram } from "lucide-react";
import { LOGO_B64 } from "@/logoB64";

export default function Footer() {
  return (
    <footer className="bg-[#111110] text-white">
      <div className="mx-auto max-w-[1440px] px-5 lg:px-10 py-14">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-8">

          {/* Brand */}
          <div className="flex items-center gap-3">
            <img src={LOGO_B64} alt="Dodds Store"
              className="w-10 h-10 object-cover rounded-full"
              style={{ border: "1px solid rgba(255,255,255,0.15)" }}
            />
            <div>
              <p className="font-display text-lg font-black tracking-[0.15em]">DODDS STORE</p>
              <p className="text-white/30 text-xs tracking-wider mt-0.5">Batna — 🇩🇿 58 Wilayas</p>
            </div>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-3">
            <a href="https://instagram.com/dodds__store" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-2 text-white/40 hover:text-white transition-colors text-sm">
              <Instagram className="w-4 h-4" />
              @dodds__store
            </a>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-white/20 text-xs tracking-wider font-display">
            © {new Date().getFullYear()} DODDS STORE — Tous droits réservés
          </p>
          <p className="text-white/15 text-xs">Manga · Figurines · Accessoires</p>
        </div>
      </div>
    </footer>
  );
}
