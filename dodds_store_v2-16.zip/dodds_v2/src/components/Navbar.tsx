import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { ShoppingCart, Search, Menu, X, Instagram, Settings } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useCartStore } from "@/stores/cartStore";
import { useProductStore } from "@/stores/productStore";
import { LOGO_B64 } from "@/logoB64";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { openDrawer, items } = useCartStore();
  const { setSearchQuery: setStoreSearch } = useProductStore();
  const location = useLocation();
  const navigate = useNavigate();
  const isStore = location.pathname === "/";
  const totalItems = items.reduce((s, i) => s + i.quantity, 0);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", fn);
    return () => window.removeEventListener("scroll", fn);
  }, []);

  const scrollTo = (id: string) => {
    setMobileOpen(false);
    if (!isStore) {
      navigate("/");
      setTimeout(() => document.getElementById(id)?.scrollIntoView({ behavior: "smooth" }), 300);
      return;
    }
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setStoreSearch(searchQuery);
    setSearchOpen(false);
    if (!isStore) navigate("/");
  };

  const textColor = scrolled ? "#111110" : "white";
  const mutedColor = scrolled ? "#888884" : "rgba(255,255,255,0.55)";

  return (
    <>
      <nav className={`fixed top-0 z-50 w-full transition-all duration-300 ${
        scrolled ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-[#E0DED8]" : "bg-transparent"
      }`}>
        <div className="mx-auto flex h-16 max-w-[1440px] items-center justify-between px-5 lg:px-10">

          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 group">
            <img src={LOGO_B64} alt="Logo"
              className="w-8 h-8 object-cover rounded-full transition-all"
              style={{ border: `1.5px solid ${scrolled ? "rgba(0,0,0,0.1)" : "rgba(255,255,255,0.2)"}` }} />
            <span className="font-display text-base font-black tracking-[0.14em]"
              style={{ color: textColor }}>
              DODDS STORE
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden items-center gap-7 md:flex">
            {["MANGA", "FIGURINES", "ACCESSOIRES"].map(label => (
              <button key={label} onClick={() => scrollTo("products-section")}
                className="font-display text-[11px] font-bold tracking-[0.2em] uppercase transition-colors hover:opacity-100"
                style={{ color: mutedColor }}>
                {label}
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="flex items-center gap-3.5">
            <button onClick={() => setSearchOpen(!searchOpen)}
              style={{ color: mutedColor }} className="transition-colors hover:opacity-100">
              <Search className="h-[17px] w-[17px]" />
            </button>

            <a href="https://instagram.com/dodds__store" target="_blank" rel="noopener noreferrer"
              className="hidden sm:block transition-colors"
              style={{ color: mutedColor }}>
              <Instagram className="h-[17px] w-[17px]" />
            </a>

            {/* Admin button */}
            <Link to="/admin" title="Dashboard Admin"
              style={{ color: mutedColor }} className="hidden sm:block transition-colors hover:opacity-100">
              <Settings className="h-[17px] w-[17px]" />
            </Link>

            <button onClick={openDrawer} className="relative transition-colors"
              style={{ color: textColor }}>
              <ShoppingCart className="h-[17px] w-[17px]" />
              <AnimatePresence>
                {totalItems > 0 && (
                  <motion.span initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
                    className="absolute -right-2 -top-1 flex h-4 w-4 items-center justify-center rounded-full bg-[#D42B2B] text-[10px] font-bold text-white">
                    {totalItems}
                  </motion.span>
                )}
              </AnimatePresence>
            </button>

            <button onClick={() => setMobileOpen(!mobileOpen)}
              className="md:hidden" style={{ color: textColor }}>
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </nav>

      {/* Search overlay */}
      <AnimatePresence>
        {searchOpen && (
          <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
            className="fixed left-0 right-0 top-16 z-40 bg-white border-b border-[#E0DED8]">
            <form onSubmit={handleSearch} className="mx-auto flex max-w-[1440px] items-center gap-4 px-5 py-4">
              <Search className="h-4 w-4 text-[#BEBEBB] flex-shrink-0" />
              <input type="text" placeholder="Rechercher un manga, une série..."
                value={searchQuery} onChange={e => setSearchQuery(e.target.value)} autoFocus
                className="flex-1 bg-transparent text-sm text-[#111110] outline-none placeholder:text-[#BEBEBB]" />
              <button type="button" onClick={() => { setSearchOpen(false); setSearchQuery(""); setStoreSearch(""); }}>
                <X className="h-4 w-4 text-[#BEBEBB] hover:text-[#111110]" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="fixed left-0 right-0 top-16 z-40 md:hidden overflow-hidden bg-white border-b border-[#E0DED8]">
            <div className="flex flex-col px-6 py-5 gap-5">
              {["MANGA", "FIGURINES", "ACCESSOIRES"].map(label => (
                <button key={label} onClick={() => { setMobileOpen(false); scrollTo("products-section"); }}
                  className="text-left font-display text-xl font-black tracking-wide text-[#111110]">
                  {label}
                </button>
              ))}
              <Link to="/admin" onClick={() => setMobileOpen(false)}
                className="flex items-center gap-2 font-display text-base font-bold text-[#888884] hover:text-[#111110] transition-colors">
                <Settings className="w-4 h-4" /> ADMIN DASHBOARD
              </Link>
              <a href="https://instagram.com/dodds__store" target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 font-display text-base text-[#888884] hover:text-[#D42B2B]">
                <Instagram className="h-4 w-4" /> @dodds__store
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
