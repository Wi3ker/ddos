// Auto-seed disabled — products are managed via the Admin Dashboard
export async function seedDatabase() {
  return;
}
