import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyCnindHKVnh6pzGZGYpnSlKVJo91RBEjBU",
  authDomain: "manga-store-bba2d.firebaseapp.com",
  projectId: "manga-store-bba2d",
  storageBucket: "manga-store-bba2d.firebasestorage.app",
  messagingSenderId: "839315965133",
  appId: "1:839315965133:web:c0d24b21b3e7982ab35584",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
