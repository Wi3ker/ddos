import { create } from "zustand";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from "@/firebase";
import type { Product, Category } from "@/types";

export const CATEGORIES: Category[] = [
  "All", "Shōnen", "Seinen", "Shōjo", "Slice of Life", "Isekai", "Special", "Figurines", "Accessories",
];

interface ProductStore {
  products: Product[];
  isLoading: boolean;
  selectedCategory: Category;
  searchQuery: string;
  setCategory: (cat: Category) => void;
  setSearchQuery: (q: string) => void;
  filteredProducts: Product[];
}

export const useProductStore = create<ProductStore>((set, get) => ({
  products: [],
  isLoading: true,
  selectedCategory: "All",
  searchQuery: "",
  setCategory: (cat) => set({ selectedCategory: cat }),
  setSearchQuery: (q) => set({ searchQuery: q }),
  get filteredProducts() {
    const { products, selectedCategory, searchQuery } = get();
    return products
      .filter((p) => {
        const matchCat = selectedCategory === "All" || p.category === selectedCategory;
        const matchSearch =
          !searchQuery ||
          p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.series.toLowerCase().includes(searchQuery.toLowerCase());
        return matchCat && matchSearch;
      })
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
  },
}));

export function initProductListener() {
  // No orderBy — avoids needing a Firestore composite index
  const unsub = onSnapshot(collection(db, "products"), (snap) => {
    const products = snap.docs.map((doc) => ({ id: doc.id, ...doc.data() } as Product));
    useProductStore.setState({ products, isLoading: false });
  }, (error) => {
    console.error("Firestore error:", error);
    useProductStore.setState({ isLoading: false });
  });
  return unsub;
}
