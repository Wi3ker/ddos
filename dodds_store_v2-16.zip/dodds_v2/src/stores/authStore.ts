import { create } from "zustand";

interface AuthStore {
  isAuthenticated: boolean;
  login: (pw: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthStore>((set) => ({
  isAuthenticated: sessionStorage.getItem("dodds_admin") === "true",
  login: (pw) => {
    const correct = import.meta.env.VITE_ADMIN_PASSWORD || "dodds2025";
    if (pw === correct) {
      sessionStorage.setItem("dodds_admin", "true");
      set({ isAuthenticated: true });
    }
  },
  logout: () => {
    sessionStorage.removeItem("dodds_admin");
    set({ isAuthenticated: false });
  },
}));
